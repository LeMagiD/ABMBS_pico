#ifndef MY_TASKS__
#define MY_TASKS__

static void MainTask(void *pv);
void LedTaskQuizSW5(void *pv);
void MakeLedTask(void);
#endif